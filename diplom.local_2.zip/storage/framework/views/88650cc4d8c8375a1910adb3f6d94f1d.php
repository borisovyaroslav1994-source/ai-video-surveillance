

<?php $__env->startSection('page_title', 'Події AI'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">

    <div>
        <h2>Події AI</h2>
        <p>
            Журнал розпізнавань: <?php echo e($events->total()); ?>

            записів <?php if(request()->filled('date')): ?>за <?php echo e(request('date')); ?><?php endif; ?>
        </p>
    </div>

</div>



<div class="alert alert-info" id="newEventsBanner" style="display:none;">

    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
    </svg>

    <span>Надійшли нові події AI.</span>

    <button type="button" class="btn btn-outline" onclick="location.reload()">
        Оновити
    </button>

</div>



<div class="card" style="margin-bottom:18px;">

    <form id="eventsFilter" method="GET" action="<?php echo e(route('events.index')); ?>">

        <div class="card-pad filters-row">

            <div class="field">

                <label for="f-camera">Камера</label>

                <select id="f-camera" name="camera_id" class="input">

                    <option value="">Усі камери</option>

                    <?php $__currentLoopData = $cameras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($camera->id); ?>"
                                <?php if(request('camera_id') == $camera->id): echo 'selected'; endif; ?>>
                            <?php echo e($camera->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>

            <div class="field">

                <label for="f-object">Об'єкт</label>

                <select id="f-object" name="object" class="input">

                    <option value="">Усі об'єкти</option>

                    <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($object); ?>"
                                <?php if(request('object') === $object): echo 'selected'; endif; ?>>
                            <?php echo e(\App\Support\ObjectIcon::badge($object)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>

            <div class="field">

                <label for="f-status">Статус</label>

                <select id="f-status" name="status" class="input">

                    <option value="">Усі</option>

                    <option value="active"
                            <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>
                        Активні
                    </option>

                    <option value="completed"
                            <?php if(request('status') === 'completed'): echo 'selected'; endif; ?>>
                        Завершені
                    </option>

                </select>

            </div>

            <div class="field">

                <label for="f-date">Дата</label>

                <input id="f-date" type="date" name="date"
                       value="<?php echo e(request('date')); ?>" class="input">

            </div>

            <div class="field" style="justify-content:flex-end;">

                <button type="submit" class="btn btn-primary">
                    Застосувати
                </button>

            </div>

        </div>

    </form>

</div>



<div class="card">

    <?php if($events->isEmpty()): ?>

        <div class="empty-state">

            <span class="empty-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                </svg>
            </span>

            <h4>Подій не знайдено</h4>

            <p>
                Спробуйте змінити фільтри або перевірте, чи запущений
                Python AI-сервер — нові події з'являються тут автоматично.
            </p>

            <a href="<?php echo e(route('events.index')); ?>" class="btn btn-outline">
                Скинути фільтри
            </a>

        </div>

    <?php else: ?>

        <div style="padding:18px 22px;">

            <div class="events-grid">

                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="event-card">

                        <div class="event-thumb">

                            <?php if($event->image_url): ?>
                                <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?>" loading="lazy">
                            <?php else: ?>
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="8" r="4"/>
                                    <path d="M5 21c0-4 3-6 7-6s7 2 7 6"/>
                                </svg>
                            <?php endif; ?>

                            <span class="badge badge-object event-object">
                                <?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?>

                            </span>

                        </div>

                        <div class="event-body">

                            <div class="event-meta">

                                <span>
                                    <?php echo e($event->camera_name ?? 'Камера #' . $event->camera_id); ?>

                                </span>

                                <span>
                                    <?php echo e($event->detected_at?->format('H:i:s') ?? '—'); ?>

                                </span>

                            </div>

                            <div class="confidence-bar">
                                <span style="width: <?php echo e((int) round($event->confidence * 100)); ?>%;"></span>
                            </div>

                            <div class="event-meta" style="margin-top:7px;">

                                <span>
                                    Точність <?php echo e(number_format($event->confidence * 100, 0)); ?>%
                                    · <?php echo e($event->detected_at?->format('d.m.Y') ?? ''); ?>

                                </span>

                                <span class="mini-pill <?php echo e($event->status === 'active' ? 'on' : 'off'); ?>">
                                    <?php echo e($event->status === 'active' ? 'активна' : 'завершена'); ?>

                                </span>

                            </div>

                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

        <div style="padding: 6px 22px 20px;">
            <?php echo e($events->links('pagination.custom')); ?>

        </div>

    <?php endif; ?>

</div>



<script>
    document.body.setAttribute('data-newest-event-id', '<?php echo e($newestId); ?>');
    document.body.setAttribute('data-events-api-url', '<?php echo e(url('api/events')); ?>');
</script>
<script src="<?php echo e(asset('assets/events.js')); ?>?v=1"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/events/index.blade.php ENDPATH**/ ?>
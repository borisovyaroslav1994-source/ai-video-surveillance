

<?php $__env->startSection('page_title', 'Онлайн-моніторинг'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">

    <div>
        <h2>Онлайн-моніторинг</h2>
        <p>
            Стан камер у реальному часі
            · автоматичне оновлення кожні 10 секунд
        </p>
    </div>

    <div class="page-actions">

        <span class="live-chip">
            <span class="dot"></span>
            LIVE
        </span>

        <span class="topbar-date" id="lastUpdate">—</span>

    </div>

</div>



<div class="stats-grid">

    <div class="stat-card">

        <span class="stat-icon green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 12h3l2-7 4 14 3-9 2 4h6"/>
            </svg>
        </span>

        <div>
            <div class="stat-value" id="statOnline">
                <?php echo e($onlineCameras); ?> / <?php echo e($cameras->count()); ?>

            </div>
            <div class="stat-label">Камер онлайн</div>
        </div>

    </div>

    <div class="stat-card">

        <span class="stat-icon amber">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="9"/>
                <path d="M12 8v4M12 16h.01"/>
            </svg>
        </span>

        <div>
            <div class="stat-value" id="statActive"><?php echo e($activeEvents); ?></div>
            <div class="stat-label">Активні події зараз</div>
        </div>

    </div>

    <div class="stat-card">

        <span class="stat-icon blue">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
            </svg>
        </span>

        <div>
            <div class="stat-value" id="statToday"><?php echo e($eventsToday); ?></div>
            <div class="stat-label">Подій за сьогодні</div>
        </div>

    </div>

    <div class="stat-card">

        <span class="stat-icon red">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                <rect x="3" y="6" width="12" height="12" rx="2"/>
            </svg>
        </span>

        <div>
            <div class="stat-value">
                <?php echo e($cameras->where('recording_enabled')->count()); ?>

            </div>
            <div class="stat-label">Камер із записом</div>
        </div>

    </div>

</div>



<div class="card" style="margin-bottom:18px;">

    <div class="card-head">

        <h3>Камери</h3>

        <span class="card-hint" id="camerasStatusText">
            <?php echo e($cameras->count()); ?> у системі
        </span>

    </div>

    <div class="card-pad">

        <?php if($cameras->isEmpty()): ?>

            <div class="empty-state">

                <span class="empty-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                        <rect x="3" y="6" width="12" height="12" rx="2"/>
                    </svg>
                </span>

                <h4>Камер не додано</h4>

                <p>Додайте камеру, щоб бачити її стан у режимі реального часу.</p>

                <a href="<?php echo e(route('cameras.create')); ?>" class="btn btn-primary">
                    Додати камеру
                </a>

            </div>

        <?php else: ?>

            <div class="monitor-grid" id="monitorGrid">

                <?php $__currentLoopData = $cameras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="monitor-tile" id="cam-<?php echo e($camera->id); ?>">

                        
                        <?php if($camera->status === 'online' && $camera->type === 'http' && str_contains(strtolower($camera->source), 'm3u8')): ?>
                            <div class="monitor-preview">
                                <video class="monitor-live" data-live-src="<?php echo e($camera->source); ?>" muted autoplay playsinline></video>
                                <span class="monitor-loading">Завантаження потоку…</span>
                            </div>
                        <?php elseif($camera->status === 'online' && $camera->type === 'http'): ?>
                            <div class="monitor-preview">
                                <img src="<?php echo e($camera->source); ?>" alt="<?php echo e($camera->name); ?>"
                                     data-mjpeg="true">
                            </div>
                        <?php else: ?>
                            <div class="monitor-preview monitor-preview-off">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                     stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                                    <rect x="3" y="6" width="12" height="12" rx="2"/>
                                </svg>
                                <span class="monitor-message">
                                    <?php if($camera->status === 'offline'): ?>
                                        Камера offline
                                    <?php else: ?>
                                        Прямий перегляд недоступний для <?php echo e(strtoupper($camera->type)); ?>

                                    <?php endif; ?>
                                </span>
                            </div>
                        <?php endif; ?>

                        <div class="monitor-tile-body">

                            <div class="monitor-tile-row">

                                <strong class="monitor-name"><?php echo e($camera->name); ?></strong>

                                <span class="badge badge-offline monitor-status"
                                      data-status="<?php echo e($camera->status); ?>">
                                    <span class="dot"></span>
                                    <?php echo e(strtoupper($camera->status)); ?>

                                </span>

                            </div>

                            <span class="monitor-sub">
                                <?php echo e($camera->location ?? 'Без розташування'); ?> ·
                                <?php echo e(strtoupper($camera->type)); ?>

                            </span>

                            <div class="monitor-pills">

                                <?php if($camera->ai_enabled): ?>
                                    <span class="mini-pill on">AI</span>
                                <?php endif; ?>

                                <?php if($camera->recording_enabled): ?>
                                    <span class="mini-pill on">REC</span>
                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        <?php endif; ?>

    </div>

</div>



<div class="card">

    <div class="card-head">

        <h3>Останні події</h3>

        <div class="page-actions" style="gap:8px;">

            <span class="card-hint" id="monitorEventCount">
                <?php echo e($recentEvents->count()); ?> за останню добу
            </span>

            <a href="<?php echo e(route('events.index')); ?>" class="card-hint">Журнал →</a>

        </div>

    </div>

    <div class="monitor-events-list" id="monitorEventsList">

        <?php $__empty_1 = true; $__currentLoopData = $recentEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="monitor-event" data-id="<?php echo e($event->id); ?>">

                <?php if($event->image_url): ?>
                    <span class="monitor-event-thumb">
                        <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?>" loading="lazy">
                    </span>
                <?php else: ?>
                    <span class="monitor-event-thumb monitor-event-thumb-ph">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"
                             stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M5 21c0-4 3-6 7-6s7 2 7 6"/>
                        </svg>
                    </span>
                <?php endif; ?>

                <span class="monitor-event-info">
                    <strong><?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?></strong>
                    <span><?php echo e($event->camera_name ?? 'Камера #' . $event->camera_id); ?></span>
                </span>

                <span class="mini-pill <?php echo e($event->status === 'active' ? 'on' : 'off'); ?>">
                    <?php echo e($event->status === 'active' ? 'активна' : 'завершена'); ?>

                </span>

                <span class="monitor-event-time">
                    <?php echo e($event->detected_at?->format('d.m H:i:s') ?? '—'); ?>

                </span>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="empty-state">

                <span class="empty-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                    </svg>
                </span>

                <h4>Подій ще немає</h4>

                <p>Запустіть Python AI-сервер — нові події з'являться тут автоматично.</p>

            </div>

        <?php endif; ?>

    </div>

</div>



<script>
    window.MONITOR_CONFIG = {
        dataUrl: '<?php echo e(route('monitoring.data')); ?>',
        newestId: <?php echo e($newestEventId); ?>

    };
</script>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js"></script>
<script src="<?php echo e(asset('assets/monitoring.js')); ?>?v=2"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/monitoring/index.blade.php ENDPATH**/ ?>
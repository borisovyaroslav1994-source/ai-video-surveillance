<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <title><?php echo $__env->yieldContent('page_title', 'Огляд системи'); ?> — <?php echo e(\App\Models\PanelSetting::getValue('panel_name', 'AI VIDEO')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/app.css')); ?>?v=1">
</head>
<body>

<?php
    $user = auth()->user();
    $userInitial = $user ? mb_strtoupper(mb_substr(trim($user->name) ?: 'U', 0, 1)) : 'U';
?>

<div class="app-shell" id="appShell">

    <!-- ==================== САЙДБАР ==================== -->
    <aside class="sidebar">

        <div class="sidebar-brand">
            <span class="brand-mark">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round" width="22" height="22">
                    <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                    <rect x="3" y="6" width="12" height="12" rx="2"/>
                </svg>
            </span>
            <span>
                <span class="brand-name"><?php echo e(\App\Models\PanelSetting::getValue('panel_name', 'AI VIDEO')); ?></span>
                <span class="brand-sub"><?php echo e(\App\Models\PanelSetting::getValue('panel_subtitle', 'Система відеонагляду')); ?></span>
            </span>
        </div>

<?php
    $perms = $user ? $user->effectivePermissions() : [];
?>

        <nav class="sidebar-nav">

            <?php if(($perms['dashboard'] ?? true)): ?>
            <a href="<?php echo e(route('dashboard')); ?>"
               class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 10.5 12 3l9 7.5"/>
                    <path d="M5 9.5V21h14V9.5"/>
                    <path d="M9.5 21v-6h5v6"/>
                </svg>
                Головна
            </a>
            <?php endif; ?>

            <?php if(($perms['cameras'] ?? false)): ?>
            <a href="<?php echo e(route('cameras.index')); ?>"
               class="nav-link <?php echo e(request()->routeIs('cameras.*') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                    <rect x="3" y="6" width="12" height="12" rx="2"/>
                </svg>
                Камери
            </a>
            <?php endif; ?>

            <?php if(($perms['monitoring'] ?? false)): ?>
            <a href="<?php echo e(route('monitoring.index')); ?>"
               class="nav-link <?php echo e(request()->routeIs('monitoring.*') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M2 12h3l2-7 4 14 3-9 2 4h6"/>
                </svg>
                Моніторинг
            </a>
            <?php endif; ?>

            <?php if(($perms['events'] ?? false)): ?>
            <a href="<?php echo e(route('events.index')); ?>"
               class="nav-link <?php echo e(request()->routeIs('events.*') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                </svg>
                Події AI
            </a>
            <?php endif; ?>

            <?php if(($perms['archive'] ?? false)): ?>
            <a href="<?php echo e(route('archive.index')); ?>"
               class="nav-link <?php echo e(request()->routeIs('archive.*') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="4" width="20" height="16" rx="2"/>
                    <path d="M10 9l5 3-5 3z"/>
                </svg>
                Відеоархів
            </a>
            <?php endif; ?>

            <?php if(($perms['settings'] ?? false)): ?>
            <a href="<?php echo e(route('settings.index')); ?>"
               class="nav-link <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                     stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/>
                </svg>
                Налаштування
            </a>
            <?php endif; ?>

        </nav>

        <div class="sidebar-user">
            <span class="user-avatar"><?php echo e($userInitial); ?></span>
            <span class="user-meta">
                <span class="user-name"><?php echo e($user->name ?? 'Гість'); ?></span>
                <span class="user-email"><?php echo e($user->email ?? ''); ?></span>
            </span>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-btn" title="Вийти">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                        <path d="m16 17 5-5-5-5"/>
                        <path d="M21 12H9"/>
                    </svg>
                </button>
            </form>
        </div>

    </aside>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ==================== КОНТЕНТ ==================== -->
    <div class="app-main">

        <header class="topbar">
            <button class="burger" id="sidebarToggle" type="button" aria-label="Меню">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                     stroke-linecap="round">
                    <path d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>

            <h1><?php echo $__env->yieldContent('page_title', 'Огляд системи'); ?></h1>

            <span class="topbar-date"><?php echo e(now()->format('d.m.Y · H:i')); ?></span>
        </header>

        <main class="app-content">

            <?php if(session('success')): ?>
                <div class="alert alert-success" data-autohide>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/>
                        <path d="M22 4 12 14l-3-3"/>
                    </svg>
                    <span><?php echo e(session('success')); ?></span>
                    <button type="button" class="alert-close" aria-label="Закрити">&times;</button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-error">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                         stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 8v4M12 16h.01"/>
                    </svg>
                    <span><?php echo e(session('error')); ?></span>
                    <button type="button" class="alert-close" aria-label="Закрити">&times;</button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-error">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                         stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 8v4M12 16h.01"/>
                    </svg>
                    <div>
                        <strong>Виправте помилки:</strong>
                        <ul class="alert-list">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <button type="button" class="alert-close" aria-label="Закрити">&times;</button>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>
</div>

<script src="<?php echo e(asset('assets/app.js')); ?>?v=1"></script>
</body>
</html>
<?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/layouts/panel.blade.php ENDPATH**/ ?>
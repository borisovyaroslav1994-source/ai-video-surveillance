

<?php $__env->startSection('page_title', 'Огляд системи'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">

    <div>
        <h2>Вітаємо, <?php echo e(auth()->user()->name); ?> 👋</h2>
        <p>
            Стан камер, подій AI та архіву записів
            на <?php echo e(now()->format('d.m.Y')); ?>

        </p>
    </div>

    <div class="page-actions">

        <a href="<?php echo e(route('monitoring.index')); ?>" class="btn btn-outline">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 12h3l2-7 4 14 3-9 2 4h6"/>
            </svg>
            Моніторинг
        </a>

        <a href="<?php echo e(route('cameras.create')); ?>" class="btn btn-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 5v14M5 12h14"/>
            </svg>
            Додати камеру
        </a>

        <a href="<?php echo e(route('archive.index')); ?>" class="btn btn-outline">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2"/>
                <path d="M10 9l5 3-5 3z"/>
            </svg>
            Відеоархів
        </a>

    </div>

</div>



<div class="stats-grid">

    <a href="<?php echo e(route('cameras.index')); ?>" class="stat-card">

        <span class="stat-icon blue">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                <rect x="3" y="6" width="12" height="12" rx="2"/>
            </svg>
        </span>

        <div>
            <div class="stat-value"><?php echo e($stats['cameras_total']); ?></div>
            <div class="stat-label">Камер у системі</div>
        </div>

    </a>

    <div class="stat-card">

        <span class="stat-icon green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M2 12h3l2-7 4 14 3-9 2 4h6"/>
            </svg>
        </span>

        <div>
            <div class="stat-value">
                <?php echo e($stats['cameras_online']); ?>

                <span style="font-size:14px; color:var(--muted); font-weight:600;">
                    / <?php echo e($stats['cameras_total']); ?>

                </span>
            </div>
            <div class="stat-label">Камер онлайн</div>
        </div>

    </div>

    <a href="<?php echo e(route('events.index')); ?>" class="stat-card">

        <span class="stat-icon amber">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
            </svg>
        </span>

        <div>
            <div class="stat-value"><?php echo e($stats['events_today']); ?></div>
            <div class="stat-label">Подій AI за сьогодні</div>
        </div>

    </a>

    <a href="<?php echo e(route('archive.index')); ?>" class="stat-card">

        <span class="stat-icon red">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2"/>
                <path d="M10 9l5 3-5 3z"/>
            </svg>
        </span>

        <div>
            <div class="stat-value">
                <?php echo e($stats['videos_today']); ?>

                <span style="font-size:13px; color:var(--muted); font-weight:600;">
                    (<?php echo e(number_format($storageBytes / 1024 / 1024 / 1024, 2, '.', '')); ?> GB)
                </span>
            </div>
            <div class="stat-label">Записів за сьогодні</div>
        </div>

    </a>

</div>



<div class="grid-2">

    

    <div class="card">

        <div class="card-head">
            <h3>Останні події AI</h3>
            <a href="<?php echo e(route('events.index')); ?>" class="card-hint">Усі події →</a>
        </div>

        <?php if($recentEvents->isEmpty()): ?>

            <div class="empty-state">

                <span class="empty-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                    </svg>
                </span>

                <h4>Подій ще немає</h4>

                <p>
                    Запустіть Python AI-сервер — події розпізнавання
                    з'являться тут автоматично.
                </p>

                <a href="<?php echo e(route('events.index')); ?>" class="btn btn-outline">
                    Перейти до журналу подій
                </a>

            </div>

        <?php else: ?>

            <div style="padding:18px 22px;">

                <div class="events-grid">

                    <?php $__currentLoopData = $recentEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="event-card">

                            <div class="event-thumb">

                                <?php if($event->image_url): ?>
                                    <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?>" loading="lazy">
                                <?php else: ?>
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                         stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
                                        <circle cx="12" cy="8" r="4"/>
                                        <path d="M5 21c0-4 3-6 7-6s7 2 7 6"/>
                                    </svg>
                                <?php endif; ?>

                                <span class="badge badge-object event-object">
                                    <?php echo e(\App\Support\ObjectIcon::badge($event->object)); ?>

                                </span>

                            </div>

                            <div class="event-body">

                                <div class="event-meta">

                                    <span><?php echo e($event->camera_name ?? 'Камера #' . $event->camera_id); ?></span>

                                    <span>
                                        <?php echo e($event->detected_at?->format('H:i:s') ?? '—'); ?>

                                    </span>

                                </div>

                                <div class="confidence-bar">
                                    <span style="width: <?php echo e((int) round($event->confidence * 100)); ?>%;"></span>
                                </div>

                                <div class="event-meta" style="margin-top:7px;">

                                    <span>
                                        Точність <?php echo e(number_format($event->confidence * 100, 0)); ?>%
                                    </span>

                                    <span>
                                        <?php echo e($event->detected_at?->format('d.m') ?? ''); ?>

                                        <?php if($event->status === 'active'): ?>
                                            · <span style="color:var(--success);">активна</span>
                                        <?php endif; ?>
                                    </span>

                                </div>

                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        <?php endif; ?>

    </div>

    

    <div class="card">

        <div class="card-head">
            <h3>Камери</h3>
            <a href="<?php echo e(route('cameras.index')); ?>" class="card-hint">Керувати →</a>
        </div>

        <?php if($cameras->isEmpty()): ?>

            <div class="empty-state">

                <span class="empty-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                        <rect x="3" y="6" width="12" height="12" rx="2"/>
                    </svg>
                </span>

                <h4>Камер не додано</h4>

                <p>Додайте першу камеру, щоб почати спостереження.</p>

                <a href="<?php echo e(route('cameras.create')); ?>" class="btn btn-primary">
                    Додати камеру
                </a>

            </div>

        <?php else: ?>

            <?php $__currentLoopData = $cameras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="camera-row">

                    <span class="badge <?php echo e($camera->status === 'online' ? 'badge-online' : ($camera->status === 'error' ? 'badge-error' : 'badge-offline')); ?>">
                        <span class="dot"></span>
                    </span>

                    <div>
                        <span class="cell-strong"><?php echo e($camera->name); ?></span>
                        <span class="cell-sub">
                            <?php echo e($camera->location ?? 'Без розташування'); ?>

                        </span>
                    </div>

                    <div class="camera-row-icons">

                        <?php if($camera->ai_enabled): ?>
                            <span class="mini-pill on">AI</span>
                        <?php endif; ?>

                        <?php if($camera->recording_enabled): ?>
                            <span class="mini-pill on">REC</span>
                        <?php endif; ?>

                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/dashboard.blade.php ENDPATH**/ ?>
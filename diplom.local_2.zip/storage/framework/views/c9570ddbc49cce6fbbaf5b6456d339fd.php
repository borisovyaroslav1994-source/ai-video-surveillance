

<?php $__env->startSection('page_title', 'Налаштування'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div>
        <h2>Налаштування</h2>
        <p>Параметри панелі та права доступу користувачів</p>
    </div>
</div>

<div class="tabs">
    <a href="<?php echo e(route('settings.index', ['tab' => 'panel'])); ?>"
       class="tab <?php echo e($tab === 'panel' ? 'active' : ''); ?>">Панель</a>
    <a href="<?php echo e(route('settings.index', ['tab' => 'users'])); ?>"
       class="tab <?php echo e($tab === 'users' ? 'active' : ''); ?>">Користувачі (<?php echo e($users->count()); ?>)</a>
</div>

<?php if($tab === 'panel'): ?>
<form method="POST" action="<?php echo e(route('settings.panel.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php $__currentLoopData = $catalogue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="margin-bottom:18px;">
        <div class="card-head"><h3><?php echo e($group['label'] ?? $groupKey); ?></h3></div>
        <div class="card-pad" style="display:flex; flex-direction:column; gap:16px;">
            <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $k = $item['key'];
                $row = $stored->get($k);
                $cur = $row ? $row->value : ($item['default'] ?? '');
            ?>
            <div class="field">
                <label for="set-<?php echo e($k); ?>"><?php echo e($item['label'] ?? $k); ?></label>
                <?php if(($item['type'] ?? 'string') === 'integer'): ?>
                <input id="set-<?php echo e($k); ?>" type="number" min="0"
                       name="settings[<?php echo e($k); ?>]" value="<?php echo e(old('settings.'.$k, $cur)); ?>"
                       class="input" style="max-width:280px;">
                <?php else: ?>
                <input id="set-<?php echo e($k); ?>" type="text"
                       name="settings[<?php echo e($k); ?>]" value="<?php echo e(old('settings.'.$k, $cur)); ?>"
                       class="input">
                <?php endif; ?>
                <?php if(!empty($item['description'])): ?>
                <span class="field-hint"><?php echo e($item['description']); ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="submit" class="btn btn-primary">Зберегти налаштування</button>
</form>
<?php else: ?>
<?php echo $__env->make('settings.users', ['users' => $users], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/settings/index.blade.php ENDPATH**/ ?>
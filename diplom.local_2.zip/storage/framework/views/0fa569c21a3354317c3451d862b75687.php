<?php if($paginator->hasPages()): ?>

<nav class="pager">

    

    <?php if($paginator->onFirstPage()): ?>
        <span class="pager-btn disabled">‹</span>
    <?php else: ?>
        <a class="pager-btn" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">‹</a>
    <?php endif; ?>

    

    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if(is_string($element)): ?>
            <span class="pager-dots"><?php echo e($element); ?></span>
        <?php endif; ?>

        <?php if(is_array($element)): ?>

            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($page == $paginator->currentPage()): ?>
                    <span class="pager-btn active"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a class="pager-btn" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    <?php if($paginator->hasMorePages()): ?>
        <a class="pager-btn" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">›</a>
    <?php else: ?>
        <span class="pager-btn disabled">›</span>
    <?php endif; ?>

</nav>

<?php endif; ?>
<?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/pagination/custom.blade.php ENDPATH**/ ?>
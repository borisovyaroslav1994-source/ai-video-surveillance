<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <title>Вхід — AI Video Surveillance</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/app.css')); ?>?v=1">
</head>
<body>

<div class="auth-page">

    <div>

        <div class="auth-card">

            <div class="auth-brand">

                <span class="brand-mark">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                         stroke-linecap="round" stroke-linejoin="round" width="22" height="22">
                        <path d="M15 10l4.55-2.28A1 1 0 0 1 21 8.62v6.76a1 1 0 0 1-1.45.9L15 14"/>
                        <rect x="3" y="6" width="12" height="12" rx="2"/>
                    </svg>
                </span>

                <span>
                    <span class="brand-name" style="color:var(--text);">AI VIDEO</span>
                    <span class="brand-sub">Система спостереження</span>
                </span>

            </div>

            <h1 class="auth-title">Вхід до системи</h1>

            <p class="auth-sub">Введіть облікові дані для продовження</p>

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <span><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>" class="auth-form">

                <?php echo csrf_field(); ?>

                <div class="field">

                    <label for="email">Email адреса</label>

                    <input id="email"
                           type="email"
                           name="email"
                           value="<?php echo e(old('email')); ?>"
                           required
                           autofocus
                           autocomplete="username"
                           placeholder="admin@example.com"
                           class="input <?php echo e($errors->has('email') ? 'invalid' : ''); ?>">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="field-error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="field">

                    <label for="password">Пароль</label>

                    <input id="password"
                           type="password"
                           name="password"
                           required
                           autocomplete="current-password"
                           placeholder="••••••••"
                           class="input <?php echo e($errors->has('password') ? 'invalid' : ''); ?>">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="field-error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="auth-row">

                    <label class="switch">
                        <input type="checkbox" name="remember">
                        <span class="switch-track"></span>
                        <span class="switch-text">Запам'ятати мене</span>
                    </label>

                    <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>">Забули пароль?</a>
                    <?php endif; ?>

                </div>

                <button type="submit" class="btn btn-primary" style="width:100%;">
                    Увійти
                </button>

            </form>
        </div>

        <p class="auth-footer">© <?php echo e(date('Y')); ?> AI Video Surveillance · Дипломний проєкт</p>

    </div>

</div>

</body>
</html>
<?php /**PATH D:\MrBorshch\OSPanel\home\diplom.local\resources\views/auth/login.blade.php ENDPATH**/ ?>